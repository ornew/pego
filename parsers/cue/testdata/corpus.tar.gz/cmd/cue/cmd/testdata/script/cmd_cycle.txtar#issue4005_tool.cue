package p

import "tool/cli"

#Size: {
	input: int
	size: [
		if input > 10 {"large"},
		"small"
	][0]
}

command: main: {
	input: 123
	dump: cli.Print & {
		text: (#Size & {
			input: input
			// The correct, non-cyclic form would be...
			// "input": 123
		}).size
	}
}
