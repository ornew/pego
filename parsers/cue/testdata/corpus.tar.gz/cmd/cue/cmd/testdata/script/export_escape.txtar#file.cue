package hello

simple: "hello"
specialJSON: #"\ ""#
specialHTML: "& < >"
