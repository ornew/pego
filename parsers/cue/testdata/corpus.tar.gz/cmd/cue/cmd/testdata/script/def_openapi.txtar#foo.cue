// Some clever title.

$version: "v1"

#Foo: {
    a: int
    b: uint & <10
}

#Bar: {
    foo: #Foo
}

