package home

import "tool/cli"

command: testdata: {
	mkdirInputs: cli.Mkdir & {
		path: "input"
	}
}
