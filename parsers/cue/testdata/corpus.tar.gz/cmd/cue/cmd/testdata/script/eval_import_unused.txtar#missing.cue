import "list"

out: 123
