@extern(embed)
package toplevel_multi
@embed(file="x.json")
@embed(file="y.json")
