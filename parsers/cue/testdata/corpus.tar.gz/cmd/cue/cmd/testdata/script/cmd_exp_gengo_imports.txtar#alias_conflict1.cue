package p

// Two files import two different packages under the same alias.
import same "mod.test/foo"

#Conflict: foo: same.#Foo
