package hello

root: {
    message: "Hello \(_who)!" // who declared in data.cue

    nested: a1: "one level"
    nested: a2: b: "two levels"
}
