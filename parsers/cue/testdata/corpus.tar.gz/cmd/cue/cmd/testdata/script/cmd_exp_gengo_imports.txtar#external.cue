// TODO: decide how gengotypes should deal with external CUE dependencies.
// What is a reasonable place to generate their Go types?
// package p

import "example.com/many@v0:foo"

#External: {
	versionedAndQualified: foo.#Foo
}
