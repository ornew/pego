package home

import (
    "encoding/json"
    "strings"
    "tool/cli"
    "tool/exec"
)

foo: {
  #a: string
  b: #a
}

command: do: {
    inputs: name: exec.Run & {
        cmd:    "echo cue"
        stdout: string
    }
    outputs: print: cli.Print & {
        text:  json.Marshal(foo & {
            #a: strings.TrimSpace(inputs.name.stdout)
        })
    }
}

