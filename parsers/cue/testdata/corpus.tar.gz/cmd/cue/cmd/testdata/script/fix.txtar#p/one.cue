package one

out: ["foo"] + ["bar"]
