package kube

import (
 "tool/cli"
 "mod.test/blah"
)

root: blah.#Pod

root: spec: _

command: test: task: test: cli.Print & {
 for _ in root {
  text: "success"
 }
}
