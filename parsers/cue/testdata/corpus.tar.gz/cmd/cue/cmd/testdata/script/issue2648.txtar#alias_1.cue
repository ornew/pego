package p

crossfile_alias: "referenced from sibling file"
A="non ident": true
if A {
    alias1_used: true
}
