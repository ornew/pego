#a:  (#b & {x: _}).x
#b: {
    x?: #c
    #c: [string]: #c
}
