#X: {
        a: int
        b: [...int]
        c: string
}
