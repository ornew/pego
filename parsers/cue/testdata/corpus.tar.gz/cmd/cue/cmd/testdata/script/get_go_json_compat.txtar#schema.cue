package schema

import "mod.test/decls"

decls.#Root

