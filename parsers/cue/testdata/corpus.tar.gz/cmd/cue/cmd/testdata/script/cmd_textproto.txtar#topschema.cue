a: int
b: [...int]
c: string
