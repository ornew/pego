package p

import (
    "encoding/yaml"
    "tool/cli"
)

command: main: cli.Print & {
    text: yaml.Marshal(output)
}