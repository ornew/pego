#Person: {
	name!: string
	age?:  int
}
