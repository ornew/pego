message: "Hello World!"
nested: a1: "one level"
nested: a2: b: "two levels"
