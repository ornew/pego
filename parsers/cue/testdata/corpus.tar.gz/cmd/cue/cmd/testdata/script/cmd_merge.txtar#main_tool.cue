package p

import (
    "encoding/json"
    "tool/cli"
)

objects: [{a1}]

command: main: cli.Print & {
    text: json.Marshal(objects)
}