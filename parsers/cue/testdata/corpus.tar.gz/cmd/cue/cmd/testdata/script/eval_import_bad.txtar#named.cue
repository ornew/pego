package p

import "notinstd"
import "list"

list: 123
