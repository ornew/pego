package kube

import (
	"tool/cli"
	"encoding/json"
)

command: dump: cli.Print & {
	text: json.MarshalStream(objects)
}

