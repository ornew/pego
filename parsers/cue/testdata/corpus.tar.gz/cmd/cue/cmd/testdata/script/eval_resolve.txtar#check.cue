#map: {for n in nodes {"\(n.name)": n}}

