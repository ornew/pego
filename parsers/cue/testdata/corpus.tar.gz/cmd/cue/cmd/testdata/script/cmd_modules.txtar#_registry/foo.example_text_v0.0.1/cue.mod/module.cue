module: "foo.example/text@v0"
language: version: "v0.8.0"
