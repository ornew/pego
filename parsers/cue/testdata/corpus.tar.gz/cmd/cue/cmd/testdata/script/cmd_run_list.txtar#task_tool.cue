package home

command: run_list: runBase & {
	task: echo: cmd: ["echo", message]
}

