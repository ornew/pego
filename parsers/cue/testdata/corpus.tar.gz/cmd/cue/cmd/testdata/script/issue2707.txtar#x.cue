package x

xfield: "from outer x"

