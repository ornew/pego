package p

_config: #Config & {
    enabled: true
    versionList: [{Name: "foo", Version: "v1.2.3"}]
}
output: _config.versionMap["foo"]
#Config: {
    enabled!: bool
    versionList:  _
    versionMap:  (#TransformVersions & {"versionList": versionList}).versionMap
}
#Artifact: {
    Name!:    string
    Version!: string
}
#TransformVersions: {
    versionList: [...#Artifact]
    versionMap: {
        for index, artifact in versionList {
            (artifact.Name): artifact.Version
        }
    }
}
