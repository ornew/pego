package hello

import (
    "tool/cli"
    "tool/exec"
)

command: echo: {
    echo: exec.Run & {
        cmd:    "echo \(message)"
        stdout: string
    }

    task: display: cli.Print & {
        text: echo.stdout
    }
}

// Issue #924
command: echohidden: {
    echo: exec.Run & {
        cmd:    "echo Hello \(_who)!"
        stdout: string
    }

    task: display: cli.Print & {
        text: echo.stdout
    }
}
