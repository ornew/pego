// only for prod
@if(prod)

package y

a:    1 @test(foo)
bb:  2
