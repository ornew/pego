package home

// missing imports

command: pkg: {
	t: cli.Print & {
		text: "Hello world!"
	}
}

