{
    environment: "prod" | "staging" @tag(env,short=prod|staging)
}

