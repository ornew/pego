package use

import "example.com/r/kit"

x: kit.#A & {}