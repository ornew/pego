package example

#Foo: {
	x: int
	body?: {
		a: int
		b?: string
	}
}
