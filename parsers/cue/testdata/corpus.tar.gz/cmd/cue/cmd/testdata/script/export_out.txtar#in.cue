_byKind: [string]: _
for obj in (#JobBranch & {_in: image: "foo"}).out {
	_byKind: (obj.kind): obj
}

out: [for obj in _byKind {obj}]

#JobBranch: {
	IN=_in: _
	out: [(#JobLeaf & {_in: IN}).out]
}
#JobLeaf: {
	_in: _
	out: {
		kind: "Job"
		spec: image: _in.image
	}
}
