package vm

import "encoding/json"

#Authz: {
	user!: string

	authz: *false | bool

    authz: allow && !deny

    deny: *false | bool // default(false)
    allow: *false | bool  // default(true)

    if user == "alice" {
        allow: true
    }
}

// We have two kinds of authz endpoints: one that takes the user
// as part of the URL path, and one that takes a JSON body.
//
// The main purpose here is to show that requests can be routed based on their
// method type.
//
// This pattern constraint sets up the common aspects for both.
command: serve: [=~"^/authz"]: ServeJSON & {
	request: value: #Authz
	response: value: request.value.authz
}

// authz returns a boolean indicating whether the user is authorized.
// The user is specified as part of the URL path.
command: serve: "/authz/{user}": {
	method: "GET"
	request: value: user: request.pathValues.user
}

// authz returns a boolean indicating whether the user is authorized.
// The user is specified in the JSON body.
command: serve: "/authz": {
	method: "POST"
	request: value: json.Unmarshal(request.body)
}

