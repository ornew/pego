#K: string

x: [#K]: _
x: a: 1

_out: [
	for k, v in x
	if k =~ #K {v},
]
