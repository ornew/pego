@experiment(try)

package p

a?: int
// c: non-existing

try x = {value: c? + 1} if x.value > 5 {
    a: x
}

