package p

foo?: #Foo

#Foo: "hello"

