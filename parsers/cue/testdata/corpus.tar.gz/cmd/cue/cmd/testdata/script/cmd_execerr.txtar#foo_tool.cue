package foo

import (
	"tool/cli"
	"tool/exec"
)

command: cannotFail: {
	one: exec.Run & {
		cmd: ["false"]
	}
}

command: canFail: {
	errExit: exec.Run & {
		cmd: ["false"]
		stderr: string
		mustSucceed: false
	}
	errNotFound: exec.Run & {
		cmd: ["program-does-not-exist"]
		stderr: string
		mustSucceed: false
	}
	second: cli.Print & {
		text: """
			errExit:
			success=\(errExit.success)
			hasStderr=\(errExit.stderr != "")

			errNotFound:
			success=\(errNotFound.success)
			hasStderr=\(errNotFound.stderr != "")
			"""
	}
}

command: withSpaces: exec.Run & {
	cmd: ["false", "with an ignored argument"]
}
