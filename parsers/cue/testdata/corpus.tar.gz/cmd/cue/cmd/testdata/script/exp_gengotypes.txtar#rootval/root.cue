package rootval

import "foo.test/bar/root"

root.#root
