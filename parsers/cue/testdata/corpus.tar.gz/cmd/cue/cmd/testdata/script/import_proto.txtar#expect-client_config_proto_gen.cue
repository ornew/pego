// Describes the configuration state for the Mixer client library that's built into Envoy.
package client

import "acme.test/api/mixer/v1"

// Defines the per-service client configuration.
#ServiceConfig: {
	disableCheckCalls?:  bool           @protobuf(1,bool,name=disable_check_calls)
	disableReportCalls?: bool           @protobuf(2,bool,name=disable_report_calls)
	mixerAttributes?:    v1.#Attributes @protobuf(3,Attributes,name=mixer_attributes)
}
