package example

foo: c: true
foo: #M
#M: c?: bool

