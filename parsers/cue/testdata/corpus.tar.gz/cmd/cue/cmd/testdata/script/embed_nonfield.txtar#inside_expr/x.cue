@extern(embed)
package inside_expr
a: {
    x: *false | bool
    @embed(file=x.json)
}.x
