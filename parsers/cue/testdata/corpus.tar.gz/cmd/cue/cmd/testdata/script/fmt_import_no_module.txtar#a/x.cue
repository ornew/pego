package x

import     "mod.com/p"

x:    p.p
