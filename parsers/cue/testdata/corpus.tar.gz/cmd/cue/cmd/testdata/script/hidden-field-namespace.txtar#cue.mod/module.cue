module: "example.com/main@v0"
language: version: "v0.9.0"

deps: {
	"example.com/mod@v0": {
		default: true
		v: "v0.1.0"
	}
}
