#type: {
    x: 0
    y: 0

    if x == 0 {i: 0}
    if y == 0 {j: 0}
}

data: {
    a: #type
    b: #type

    b: x: a.x
    a: y: b.y
}
