package x

itemsList: [for _, v in items {v}]
