package p

import x "list"

out: 123
