#schema: aField!: bool

_parameters & #schema
_parameters: #template

#template: {
    #in: _input
    for _name, _content in #in {
        _content.parameters
    }
}

_input: {}

