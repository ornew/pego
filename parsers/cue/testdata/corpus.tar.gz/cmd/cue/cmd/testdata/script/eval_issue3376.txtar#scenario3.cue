#Item: {
  id!: string
  deps?: [...or(known_ids)] | or(known_ids)
}

known_ids: [for k,v in items { v.id } ]

items: [string]: #Item

items: [Key=_]: { id: (Key) + "-id" }

items: a: deps: items.b.id
items: b: deps: []
items: c: deps: [items.a.id, items.b.id]
items: d: _

