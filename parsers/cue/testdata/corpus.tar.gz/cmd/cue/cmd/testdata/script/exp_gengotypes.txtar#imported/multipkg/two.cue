package multipkg_two

@go(multipkg)

#Two: int
