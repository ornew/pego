@extern(embed)

package foo

none: _@embed(type=foo)

both: _ @embed(file=test.json, glob="x/*.*", type=yaml)

dotdot: _ @embed(file="../test.json")

abs: _ @embed(file=/input.yaml)

nonexist: _ @embed(file=y/test.json, type=text)

dir: _ @embed(glob="x", type=yaml)

dirslash: _ @embed(glob="x/", type=yaml)

dotdotglob: _ @embed(glob="../test.json", type=yaml)

absglob: _ @embed(glob="/x/*.*", type=yaml)

doublestar: _ @embed(glob="**/*.json")

stream: _ @embed(file=test.ndjson)

singlestream: _ @embed(file=single.ndjson)

yamlstream: _ @embed(file=stream.yaml)

textproto: _ @embed(file=test.textproto)

norm1: _ @embed(file=./test.json)

norm2: _ @embed(file="x/../test.json")

norm3: _ @embed(file="x/../x/test.json")

norm4: _ @embed(file="x//test.json")

noTranslateBS: _ @embed(file="x\\test.json")

autoCUEfiletype: _ @embed(file="x.cue")
explicitCUEfiletype: _ @embed(file=xcue, type=cue)

// intentional missing type arg
unspecifiedFiletype1: _ @embed(glob=x/*.*)
unspecifiedFiletype2: _ @embed(glob=x/*)
unspecifiedFiletype3: _ @embed(glob=x/*.?son)
unspecifiedFiletype4: _ @embed(glob=x/*.[j]son)

nestedModJSON: _ @embed(file="a/b/foo.json")
nestedModJSONWithGlob: _ @embed(glob="a/*/*.json")

directory: _ @embed(file="x", type=cue)

buildFailure: _ @embed(file="buildfail.cue")

invalidFiletype: _ @embed(file="x.unknown")
invalidPattern: _ @embed(glob="x[")

