package example

import (
	"encoding/json"
	"tool/file"
	"tool/cli"
)

command: info: {
	read: file.Read & {
		filename: "data.json"
		contents: _
	}
	display: cli.Print & {
		let _data = #Schema & json.Unmarshal(read.contents)
		text: "version: \(_data.Version)"
	}
}

#Schema: {
	Version!: bool
	...
}
