package hello

import (
	"tool/cli"
	"tool/exec"
)

command: echo: {
    echo: exec.Run & {
        cmd:    "cat"
        stdout: string
    }

    pass: exec.Run & {
        cmd:    "cat"
        stdin:  echo.stdout
    }
}

command: intro: {
	askName: cli.Ask & {
		prompt:   "What is your name?"
		response: string
	}

	askPlace: cli.Ask & {
		order:    askName.response
		prompt:   "Where do you live?"
		response: string
	}

	results: cli.Print & {
		text: "\nYour full name is \(askName.response) and you live in \(askPlace.response)."
	}
}

command: noreads: {
	first: exec.Run & {
		cmd: ["echo", "not reading any stdin"]
	}
}
