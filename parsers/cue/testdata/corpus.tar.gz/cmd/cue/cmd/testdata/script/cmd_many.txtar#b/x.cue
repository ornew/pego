package x

items: {
	b: "b"
}
