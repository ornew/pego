package foo

b: 42
