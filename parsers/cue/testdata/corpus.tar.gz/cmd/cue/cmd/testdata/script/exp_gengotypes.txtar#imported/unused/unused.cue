package unused

// This API and package are not used as part of the generated schemas.
#UnusedNeverGenerate: int
