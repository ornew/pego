package vm

import (
	"encoding/json"
	"tool/exec"  // Uncomment when experimenting with sibling task pattern
	"tool/http"
)

// Test serves as an endpoint for simple testing.
command: serve: "/test": http.Serve & {
	request: _
	response: body: "ack: using method \(request.method)"
}

// This endpoint demonstrates capture of all path parameters.
command: serve: "/one/{one}/{two...}": http.Serve & {
	request: _
	response: body: "ack: one/\(request.pathValues.one) \(request.pathValues.two)"
}

// This endpoint demonstrates a sibling task (defined as a separate command)
// that reads from the request and produces output used in the response.
command: serve: "/echo": http.Serve & {
	routing: method: "POST"
	request: _
	// Reference the sibling command's output
	response: body: command.echo.stdout
}

// The echo task is defined as a sibling command that reads from the serve request.
command: echo: exec.Run & {
	cmd: ["cat"]
	stdin:  command.serve."/echo".request.body
	stdout: string  // Explicitly capture stdout
}

// ServeJSON is a helper for endpoints that serve JSON.
ServeJSON: {
	response: {
		value!: _
		body:  json.Marshal(value)
	}
}

// All our endpoints serve from the same address.
// We take the convention that the name of the "subcommand" is the path prefix.
command: serve: [Prefix=string]: http.Serve & {
	listenAddr: ":8082"
	routing: path: Prefix
}
