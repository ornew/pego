@extern(embed)
package field_multi
a: _ @embed(file=x.json) @embed(file=y.json)
