module: "example.com/mod@v0"
language: version: "v0.9.0"
