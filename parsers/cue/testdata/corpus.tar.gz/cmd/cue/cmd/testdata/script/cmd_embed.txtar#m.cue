package x
import (
	"tool/cli"
	"mod.test/hello"
)

hello

command: hello1: task: hello: cli.Print & {
	text: "hello, world"
}
