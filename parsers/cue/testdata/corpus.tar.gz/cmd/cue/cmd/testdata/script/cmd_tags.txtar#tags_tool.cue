package tags

import (
    "encoding/json"
    "tool/cli"
)

tooldata: {
    enable: _ | *true @tag(toolenable,type=bool)
}

command: tag: cli.Print & {
    text: """
        data.json: \(json.Marshal(data))
        tooldata.json: \(json.Marshal(tooldata))
        """
}
