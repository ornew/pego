import (
    "path"
    "tool/cli"
)

wd: string @tag(wd,var=cwd)
_os: string @tag(os,var=os)

command: user: {
    base: cli.Print & { text: path.Base(wd, _os) }
}

