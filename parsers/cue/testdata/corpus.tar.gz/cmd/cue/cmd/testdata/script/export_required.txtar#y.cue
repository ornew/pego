a: x!: 5
a: x?: int // do not include this position

#Def: {
	x!: int
}

b: #Def
