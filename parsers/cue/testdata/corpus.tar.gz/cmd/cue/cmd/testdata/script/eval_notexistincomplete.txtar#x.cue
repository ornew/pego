package x

import "list"

x: [1, 2, 3]
sortedx: list.Sort(x, cmp)

cmp: _

