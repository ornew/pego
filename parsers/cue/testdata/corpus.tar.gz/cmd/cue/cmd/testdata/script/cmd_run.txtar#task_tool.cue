package home

command: run: #RunBase & {
	task: echo: cmd: "echo \(message)"
}

