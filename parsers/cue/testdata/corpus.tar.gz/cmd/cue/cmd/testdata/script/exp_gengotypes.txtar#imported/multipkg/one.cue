package multipkg_one

@go(multipkg)

#One: int
