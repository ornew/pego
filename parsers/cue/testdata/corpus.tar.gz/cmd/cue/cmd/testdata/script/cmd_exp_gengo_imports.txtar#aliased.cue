package p

import (
	// Two "v1" packages imported in the same file, one with an alias.
	v1_aliased "mod.test/api/meta/v1"
	"mod.test/api/core/v1"
)

#Aliased: {
	meta: v1_aliased.#ObjectMeta
	spec: v1.#PodSpec
}
