"quoted": b
