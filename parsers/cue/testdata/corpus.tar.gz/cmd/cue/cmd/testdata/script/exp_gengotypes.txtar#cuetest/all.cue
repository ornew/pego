package cuetest

pass: empty: {}
fail: both: notString: "not_a_struct"
fail: both: notList:   [1, 2, 3]

pass: noOptional:           fields: {required: 3, regular: 4}
pass: withOptional:         fields: {required: 3, regular: 4, optionalBasic: 5}
fail: cue: missingRequired: fields: regular: 4

fail: cue: isNotEqual: {mustEqual1: 8, mustEqual2: 99}
pass: isEqual:         {mustEqual1: 8, mustEqual2: 8}

fail: cue: discBoth: discriminatorField: {one: 5, two: 5}
pass: discOne: discriminatorField: one: 5
pass: discTwo: discriminatorField: two: 5

// To avoid repetition, we template the type test cases.
// Note that some types have multipe test cases.
for i, test in _typeTests {
	if test._fail == "none" {
		pass: "\(i)_\(test.name)": types: (test.name): test.pass
	}
	if test._fail == "cue" {
		fail: cue: "\(i)_\(test.name)": types: (test.name): test.fail.cue
	}
	if test._fail == "both" {
		fail: both: "\(i)_\(test.name)": types: (test.name): test.fail.both
	}
}
#typeTest: {
	name:   string
	isPass: bool
}
#typeTest: {
	_fail: "none"
	pass!: _
} | {
	_fail: "cue"
	fail!: cue!: _
} | {
	_fail: "both"
	fail!: both!: _
}
_typeTests: [...#typeTest] & [
	// TODO: most failure tests below should also fail in Go.

	{name: "Null",   pass: null},
	{name: "Bool",   pass: false},
	{name: "Bool",   pass: true},
	{name: "Int",    pass: 123},
	{name: "Float",  pass: 456.789},
	{name: "String", pass: "foo bar"},
	// {name: "Bytes",  pass: '\x01\x02\x03'},

	{name: "Number", pass: 12333},
	{name: "Number", pass: 123.33},
	{name: "Uint",   pass: 123456789},
	{name: "Uint",   fail: cue: -34},
	{name: "Int8",   pass: 12},
	{name: "Int8",   fail: cue: 99999},
	{name: "Int8",   fail: cue: -99999},
	{name: "Rune",   pass: 140},

	{name: "IntList",        pass:       [1, 2, 3]},
	{name: "IntList",        pass:       []},
	{name: "IntList",        fail: both: ["foo", "bar"]},
	{name: "IntListClosed2", pass: [1, 2]},
	{name: "IntListClosed2", fail: cue: [1, 2, 3, 4]}, // too long
	{name: "IntMap",         pass: {"one": 1, "two": 2}},
	{name: "IntMap",         fail: both: {"one": "x", "two": "y"}},
	{name: "Time",           pass: "1937-01-01T12:00:27.87+00:20"},
	{name: "Duration",       pass: "1h2m3s4ms"},

	{name: "StringOrInt",        pass:       "foo"},
	{name: "StringOrInt",        pass:       345},
	{name: "StringOrIntDefault", pass:       "foo"},
	{name: "StringOrIntDefault", pass:       345},
	{name: "NullOrStruct",       pass:       null},
	{name: "NullOrStruct",       pass:       {foo: 3}},
	{name: "NullOrStruct",       fail: cue:  "foo"},
	{name: "NullOrString",       pass:       null},
	{name: "NullOrString",       pass:       "foo"},
	{name: "NullOrString",       fail: cue:  123},
	{name: "NumericBounds",      pass:       50},
	{name: "NumericBounds",      fail: cue:  5555},
	{name: "NonEmptyString",     pass:       "foo"},
	{name: "NonEmptyString",     fail: cue:  ""},
	{name: "NonEmptyString",     fail: both: 123},
	{name: "UniqueStrings",      pass:       ["foo", "bar"]},
	{name: "UniqueStrings",      fail: cue:  ["foo", "foo"]},
	{name: "NonEmptyString",     fail: both: [1, 2, 3]},
	{name: "LinkedList",         pass:       {item: 12, next: {item: 34}}},
	{name: "LinkedList",         fail: both: {next: "x"}},
	{name: "GraphNode",          pass:       {edges: [{}, {edges: [{}]}]}},
	{name: "GraphNode",          fail: both: {edges: {}}},
]
