rand: int @tag(rand,var=rand)

