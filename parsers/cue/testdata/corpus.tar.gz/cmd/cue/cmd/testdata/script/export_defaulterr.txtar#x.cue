toto: value: *_|_ | (*"toto" | string)

