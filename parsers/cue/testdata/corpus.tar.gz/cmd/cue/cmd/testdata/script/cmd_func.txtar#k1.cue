package kube

import "encoding/json"

x: y: 2

objects: [for v in [json.Marshal(x)] {v}]

