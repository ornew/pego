package ls

import (
    "tool/cli"
    "tool/exec"
)

command: ls: {
    ls: exec.Run & {
		cmd:    "ls"
		dir:    "ls-work-dir"
		stdout: string
	}

	task: display: cli.Print & {
		text: ls.stdout
	}
}

