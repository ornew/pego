package x

items: {
	a: "a"
}
