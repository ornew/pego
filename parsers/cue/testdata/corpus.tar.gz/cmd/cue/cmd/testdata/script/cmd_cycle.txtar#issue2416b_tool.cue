package p

import (
	"strings"
	"tool/cli"
)

#Input: INPUT={
	kind: string
	outKey: string | *"default"
	if kind != "foo" {
		outKey: INPUT.kind
	}
}
inputs: f: #Input & { kind: "foo" }
inputs: b: #Input & { kind: "bar" }

outputs: [string]: string
for _, input in inputs {
	outputs: "\(input.outKey)": input.kind
}

command: print: cli.Print & {
	text: strings.Join([for key, val in outputs { "key=\(key) val=\(val)" }], "\n")
}

