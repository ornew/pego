package hello

import "tool/cli"

who: string @tag(who)

command: hello: cli.Print & {
  text: "Hello \(who)!"
}
