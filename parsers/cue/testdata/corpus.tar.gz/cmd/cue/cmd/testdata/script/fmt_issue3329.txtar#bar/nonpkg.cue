import "cue.example/foo/bar"

   bar
