package tags

data: {
    env: "prod" | "staging" @tag(env,short=prod|staging)
    name: string @tag(name)
    enable: _ @tag(enable,type=bool)
    count: _ @tag(count,type=int)
    mult: _ @tag(mult,type=number)
}

