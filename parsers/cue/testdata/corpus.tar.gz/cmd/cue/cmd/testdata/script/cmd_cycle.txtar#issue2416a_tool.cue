package kubecluster

import "tool/file"

Cluster: {}

m: x: Cluster
m: x: X={
	foobar: X.name
	name: "x"
	foo: string
}

dnsRecords: _

for _, X in m {
	dnsRecords: "\(m.x.foo)": "127.0.0.1"
}

command: build: file.Create & {
	filename: "output/dns-records.zone"
	permissions: int | *0o666
	let lines = [
		for name, addr in dnsRecords {
			"\(name) A \(addr)"
		},
	]
	contents: lines[0]
}

