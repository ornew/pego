package exitcode

import (
	pkg "foo.com/example"
)

a: 1

incomplete: pkg.Settings

foo: bar: "hello"


