package main
import "example.com/e"

e.foo

