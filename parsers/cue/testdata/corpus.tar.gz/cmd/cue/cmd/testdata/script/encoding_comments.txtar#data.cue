package p

// Data fits the schema.
Data: #Schema & {
	// name is a specific name.
	name: "Foo"
}

// implicitUnified is any non-empty string.
implicitUnified: string & != ""

// implicitUnified is some string value.
implicitUnified: "some value"

// explicitUnified1 sets a default value.
explicitUnified1: string | *"some default"

// explicitUnified2 sets a value.
explicitUnified2: "some value"

// explicitUnified unifies two values.
explicitUnified: explicitUnified1 & explicitUnified2

// disjunction1 has a default.
_disjunction1: string | *"some default"

// disjunction2 has no default.
_disjunction2: int

// disjunction is like a sum type.
disjunction: _disjunction1 | _disjunction2

