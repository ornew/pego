@extern(embed)

package e

a: _ @embed(file=foo.txt)
