package p

crossfile_simple: true
if crossfile_simple {
    simple1_used: true
}
