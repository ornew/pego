package p

A="another non ident": false
crossfile_alias_ref: crossfile_alias
alias2_mark_used: A
