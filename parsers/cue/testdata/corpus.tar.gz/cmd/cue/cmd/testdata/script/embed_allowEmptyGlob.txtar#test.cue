@extern(embed)

package foo

// Test allowEmptyGlob with no matching files
emptyGlob: _ @embed(glob="missing/*.json", allowEmptyGlob)

// Test allowEmptyGlob with matching files
nonEmptyGlob: _ @embed(glob="x/*.yaml", allowEmptyGlob)

// Test allowEmptyGlob with different file types
emptyText: _ @embed(glob="missing/*.txt", type=text, allowEmptyGlob)
emptyBinary: _ @embed(glob="missing/*.bin", type=binary, allowEmptyGlob)

