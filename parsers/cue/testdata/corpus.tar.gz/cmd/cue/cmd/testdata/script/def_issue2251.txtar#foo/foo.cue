package foo

#Foo: {
	a: string
}

