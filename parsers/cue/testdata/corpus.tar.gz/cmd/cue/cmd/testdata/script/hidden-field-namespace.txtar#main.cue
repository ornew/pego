package main

import (
	p1 "example.com/mod/subpkg"
	p2 "example.com/mod/subpkg:subpkg"
	p3 "example.com/mod:lib"
)
test1: (p1.#withx & {in: 1}).out & p1.#foo
test2: (p1.#withx & {in: 2}).out & p2.#foo
test3: (p1.#withx & {in: 3}).out & p3.#foo

