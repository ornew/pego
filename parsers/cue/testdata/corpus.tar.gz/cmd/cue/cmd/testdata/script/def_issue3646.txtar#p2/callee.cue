package p2

#RegionMap: {
	"us-east-1": "ue1"
	"us-west_1": "uw1"
}

regionMap: #RegionMap
