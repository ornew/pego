@extern(embed)

package foo

a: _ @embed(file="test.json")

b: _ @embed(file="input.yaml")

c: _ @embed(file="test.json", type=text)

d: _ @embed(glob="y/*", type=yaml)

d: _ @embed(glob="x/*.yaml") // merge into the same map

f: _ @embed(file="openapi.json", type=openapi)

g: _ @embed(file="openapi.json") // test no auto mode!

h: _ @embed(file="test-utf8-bom.binary", type=binary)

i: _ @embed(file="test-utf8-bom.binary", type=text)

j: _ @embed(file="test-nonutf8.binary", type=binary)

special: {
	// These are all valid.
	underscoreFile: _ @embed(file="y/_test.json")
	dotFile:        _ @embed(file="y/.test.json")
	dotFileExplicit: _ @embed(glob="y/.*.json", type=yaml)
	dotdotFile:        _ @embed(file="..dotdot.json")
	underscoreDir:  _ @embed(file="_y/test.json")
	dotDir:         _ @embed(file=".y/test.json")
}

