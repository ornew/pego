package pkg1

#Foo: int
