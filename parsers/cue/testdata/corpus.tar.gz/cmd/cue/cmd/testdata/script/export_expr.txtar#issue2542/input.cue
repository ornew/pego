obj: this={
	(#makeName & {enable: this._enable}).out
}

obj: _enable: true

obj2: obj

#makeName: {
	enable: bool
	if enable {
		out: name: "enabled"
	}
	if !enable {
		out: name: "disabled"
	}
}
