package lib
import "example.com/mod/subpkg@v0"

#foo: subpkg.#foo

value: "from mod module"
