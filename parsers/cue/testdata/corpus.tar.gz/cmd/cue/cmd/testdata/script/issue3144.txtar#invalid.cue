foo :: "bar"
out: foo
