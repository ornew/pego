package a

import "mod.test/a/pkg"
import "list"

v: pkg.v

// Never inline core packages.
run: list.Comparer

