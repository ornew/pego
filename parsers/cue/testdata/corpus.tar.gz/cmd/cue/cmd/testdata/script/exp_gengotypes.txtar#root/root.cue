package root

// This type is always overriden via @go() attributes, and it is hidden,
// so it should never be generated.
_#overridenNeverGenerate: string

// emptyStruct has a doc comment.
#emptyStruct: {}
#root: {
	// TODO: keep the embedding on the Go side to avoid repeating types
	#embeddedStruct

	types?: #types

	fields?: {
		regular:   int
		required?: int

		optionalBasic?: int
		optionalList?:  [...int]
		optionalMap?:   [string]: int

		optionalTopAttrNillable?:   _ @go(,optional=nillable)
		optionalNullAttrNillable?:  null @go(,optional=nillable)
		optionalBasicAttrNillable?: int @go(,optional=nillable)
		optionalListAttrNillable?:  [...int] @go(,optional=nillable)

		// Ensure that "is nillable" is worked out correctly for inline types, referenced definitions,
		// and nested types where only part of the type is not nillable, but not the top level.

		optionalInlineMapAttrNillable?:    {[string]: int} @go(,optional=nillable)
		optionalLocalMapAttrNillable?:     #localMap @go(,optional=nillable)
		optionalInlineNestedAttrNillable?: {f?: [...string]} @go(,optional=nillable)
		optionalLocalNestedAttrNillable?:  #localNested @go(,optional=nillable)

		optionalStruct?: #emptyStruct
		optionalStructAttrType?: #emptyStruct @go(,type=EmptyStruct)
		optionalStructAttrZero?: #emptyStruct @go(,optional=zero)
		optionalStructAttrNillable?: #emptyStruct @go(,optional=nillable)

		nestedStructAttrNillable: {
			optionalStruct?: #emptyStruct
			optionalStructAttrType?: #emptyStruct @go(,type=EmptyStruct) // overrides optional=nillable
			optionalStructAttrZero?: #emptyStruct @go(,optional=zero)
		} @go(,optional=nillable)

		regularStruct: field?: int

		useRegular?:       regular
		useRegularStruct?: regularStruct
	}

	// Hidden fields are not generated.
	_hiddenNeverGenerate: int

	attrName?:       int @go(AttrChangedName)
	attrNameNested?: int @go(AttrChangedNameNested)
	attrType?:       _#overridenNeverGenerate @go(,type="go/constant".Kind)
	// For compatibility with `cue get go`, an unnamed second value is also a type.
	attrTypeCompat?:  _#overridenNeverGenerate @go(,"go/token".Token)
	attrTypeNested?:  {one?: two?: three?: int} @go(,type=map[any]any)
	attrTypeComplex?: _#overridenNeverGenerate @go(,type=*[]*"go/constant".Kind)
	// See the TODO around semicolons being inserted on newlines.
	// attrTypeStruct?:  _#overridenNeverGenerate @go(,type=struct{
	// 	AttrTypeStructOne int
	// 	AttrTypeStructTwo string
	// })

	attrIgnoreNeverGenerate?: int @go(-)

	// doc is a great field.
	//
	// It deserves multiple paragraphs of documentation
	// as there is a lot to write about it.
	doc?: int

	inlineDoc?: int // this is an inline comment

	innerDoc?: {
		// This is documentation inside a struct, but not attached to any of its fields.

		innerDocField?: int
	}

	#innerStruct: innerStructField?: int
	useInnerStruct?: #innerStruct

	_#hiddenInnerStruct: innerStructField?: int
	useHiddenInnerStruct?: _#hiddenInnerStruct

	deeplyNested?: one?: two?: three?: int

	useHiddenStruct?: _#hiddenStruct

	// Hidden definitions are only generated if referenced; this one is not.
	_#unusedHiddenInnerStruct: neverGenerate?: int

	// Nested definitions are still exported via the CUE package,
	// but it's not clear whether we should generate them as Go types.
	// They might be template parameters, for example.
	// For now we don't generate them.
	#unusedInnerStruct: neverGenerate?: int

	discriminatorField?: close({one!: int}) | close({two!: int})

	mustEqual1?: int
	mustEqual2?: mustEqual1

	// Various forms of quoted fields which we can represent in Go with encoding/json.
	"with-dashes"?: string
	"with-dashes-attr"?: string @go(WithDashesNewName)
	"123LeadingNumber"?: string

	// We could represent some of these with a future encoding/json/v2,
	// but not with encoding/json today, and they seem unlikely to happen in practice.
	"with\"quotes"?:      string
	"with`backquotes"?:   string
	"with,commas"?:       string
	"with\nnewlines"?:    string
	"with\\backslashes"?: string
}

// Actually, this field needed even more documentation.
#root: doc?: _

// All definitions underneath here must not be exported.
_#hiddenStruct: {
	innerField?: int

	#innerStruct: field?: int
	innerStruct?: #innerStruct
}

#embeddedStruct: {
	embedded1?: int
	{
		embedded2?: int
	}
}

#localMap: [string]: int
#localNested: f?: [...string]

// A conditional that narrows a field of a referenced type should not
// prevent the use of that type reference in the generated Go code.
#conditionalNarrow: {
	nested: #localNested
	flag?:  bool

	if flag != _|_ {
		nested: f: [_, ...] // require at least one element in a sub-field
	}
}

// Hidden definitions are only generated if referenced; this one is not.
_#unusedHiddenStruct: neverGenerate?: int

#attrName: int @go(AttrChangedName)
#attrNameEmbed: {
	@go(AttrChangedNameEmbed)

	field?: int
}
#attrType: _#overridenNeverGenerate @go(,type="go/constant".Kind)
#attrTypeEmbed: {
	@go(,type="go/constant".Kind) // obeyed even when the type has a different kind

	neverGenerate?: int
}

#attrIgnoreNeverGenerate: int @go(-)
#attrIgnoreEmbedNeverGenerate: {
	@go(-)

	neverGenerate?: int
}
