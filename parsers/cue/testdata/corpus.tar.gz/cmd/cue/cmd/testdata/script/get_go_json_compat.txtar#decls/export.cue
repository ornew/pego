package decls

import "strings"

#Root & {
	Duration: #ValueSecond

	Strings: [
		#ErrorPrefix,
		#ResetColor,
		#UTF8,
	]
	NonUTF8ThirdByte: strings.ByteAt(#NonUTF8, 3)
}
