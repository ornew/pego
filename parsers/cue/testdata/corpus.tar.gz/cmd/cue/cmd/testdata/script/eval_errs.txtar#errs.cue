a: "hello"
b: "goodbye"
x: {q: a, q: b}

foo: {a: int} | {b: string}
bar: foo & {a: "str", b: 2}
