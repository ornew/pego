package p

import "list"

out: 123
