package before

#X: string | int

foo: [string]: #X

foo: a: "a"
foo: b: 1
