module: "example.com/r"
language: version: "v0.8.0"
