package list

nodes: [{
    name: "foo"
    childs: ["bar", "baz"]
}, {
    name:   "bar"
    parent: "foo"
}, {
    name:   "baz"
    parent: "foo"
}]

