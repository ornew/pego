package p

import (
	"tool/cli"
	"tool/file"
	"encoding/json"
)

command: inputKindOutside: {
	input: file.Read & {
		filename: "input_kind.json"
	}
	unmarshal: json.Unmarshal(input.contents)
	display: cli.Print & {
		text: unmarshal.data
	}
}
command: inputDollarIdOutside: {
	input: file.Read & {
		filename: "input_dollar_id.json"
	}
	unmarshal: json.Unmarshal(input.contents)
	display: cli.Print & {
		text: unmarshal.data
	}
}
command: inputUnderscoreIdOutside: {
	input: file.Read & {
		filename: "input_underscore_id.json"
	}
	unmarshal: json.Unmarshal(input.contents)
	display: cli.Print & {
		text: unmarshal.data
	}
}
command: inputDollarIdInside: {
	input: file.Read & {
		filename: "input_dollar_id.json"
	}
	display: cli.Print & {
		unmarshal: json.Unmarshal(input.contents)
		text: unmarshal.data
	}
}
command: inputDollarIdOutsideHidden: {
	input: file.Read & {
		filename: "input_dollar_id.json"
	}
	_unmarshal: json.Unmarshal(input.contents)
	display: cli.Print & {
		text: _unmarshal.data
	}
}

command: useCliPrintCopy: cliPrintCopy & {
	text: "hello"
}
cliPrintCopy: {
	$id: _id
	_id: *"tool/cli.Print" | "print"
	text: string
}
