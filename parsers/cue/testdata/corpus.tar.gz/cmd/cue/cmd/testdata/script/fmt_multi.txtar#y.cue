package y

// a comment
a:    1
bb:  2 @test(foo)

