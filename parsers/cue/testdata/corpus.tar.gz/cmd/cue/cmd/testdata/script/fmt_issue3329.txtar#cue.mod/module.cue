module: "cue.example/foo"
language: {
	version: "v0.9.0"
}
