package repro

import (
	"tool/cli"
	"tool/exec"
	"tool/file"
	"list"
	"path"
)

command: main: {
	inputs: file.Glob & {glob: "input/*.json"}
	// Delay "outputs" so that "inputs" is always processed first,
	// causing initTasks to discover phantom conditional tasks.
	delay:   exec.Run & {cmd: ["testcmd", "sleep_and_print", "50ms"]}
	outputs: file.Glob & {glob: "output/*.json", $after: delay}

	for _, inputpath in inputs.files {
		(inputpath): {
			_output: path.Join(["output", path.Base(inputpath)], path.Unix)
			_done:   list.Contains(outputs.files, _output)

			if _done {
				print: cli.Print & {text: "\(inputpath) already in outputs"}
			}
			if !_done {
				work: cli.Print & {text: "\(inputpath) not yet done"}
			}
		}
	}
}
