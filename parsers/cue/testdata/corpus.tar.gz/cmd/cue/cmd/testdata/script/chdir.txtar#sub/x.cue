package x

foo: 42
