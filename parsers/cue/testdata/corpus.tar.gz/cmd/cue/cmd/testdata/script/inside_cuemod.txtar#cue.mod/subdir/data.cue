package subdir

location: "in cue.mod/subdir"
