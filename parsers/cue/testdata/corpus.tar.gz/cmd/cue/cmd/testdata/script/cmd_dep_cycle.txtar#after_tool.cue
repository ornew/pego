package home

import (
	"tool/cli"
)

command: interlockedTasks: {
  t1: cli.Print & { text: t2.value, value: "v" }
  t2: cli.Print & { text: t1.value, value: "v" }
}

command: aftercycle: {
	t1: cli.Print & { $after: t2, text: "t1" }
	t2: cli.Print & { $after: t1, text: "t2" }
}

command: cycle: {
	t1: cli.Print & { text: t2.text }
	t2: cli.Print & { text: t1.text }
}
