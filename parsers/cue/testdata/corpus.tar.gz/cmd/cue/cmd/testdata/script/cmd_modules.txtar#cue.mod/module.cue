module: "main.example"
language: version: "v0.8.0"
deps: "foo.example/text@v0": {
	default: true
	v: "v0.0.1"
}
