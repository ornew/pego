package widget

#Widget: {
        model: string
        explicit: "literal string"
}

