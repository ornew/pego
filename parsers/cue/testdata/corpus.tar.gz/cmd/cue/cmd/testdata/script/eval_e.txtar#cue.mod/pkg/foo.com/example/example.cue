package example

Settings: {}
blah: Settings.anyKey

