package foo

import (
	"tool/cli"
	"tool/exec"
)

#messageText: *"hello" | string
message: *"MESSAGE=\(#messageText)" | string

command: execEnv: {
    usesDefaultsStruct: exec.Run & {
        cmd: ["testcmd", "expand", "$MESSAGE from $SENDER"]
        stdout: *"" | string
        env: {
            MESSAGE: #messageText
            SENDER: *"John Doe" | string
        }
    }
    usesDefaultsList: exec.Run & {
        cmd: ["testcmd", "expand", "$MESSAGE from $SENDER"]
        stdout: *"" | string
        env: [message, *"SENDER=John Doe" | string ]
    }
    result: cli.Print & {
        text: """
        usesDefaultsStruct: \(usesDefaultsStruct.stdout)
        usesDefaultsList: \(usesDefaultsList.stdout)
        """
    }
}
