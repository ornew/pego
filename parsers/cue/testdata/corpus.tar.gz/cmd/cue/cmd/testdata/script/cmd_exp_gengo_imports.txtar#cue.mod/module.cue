module: "mod.test"
language: {
	version: "v0.13.0"
}
deps: {
	"example.com@v0": {
		v: "v0.0.1"
	}
}
