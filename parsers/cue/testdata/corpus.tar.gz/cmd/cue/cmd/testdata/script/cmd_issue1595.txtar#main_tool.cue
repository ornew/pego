import (
	"tool/cli"
	"tool/http"
)

command: main: {
	get: http.Get & {
		url: "badproto://neverexists.localhost"
	}
	resp: get.response
	final: cli.Print & { text: resp.body }
}
