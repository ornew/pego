#Schema: {
	a?: string
	b?: b2?: string
}
