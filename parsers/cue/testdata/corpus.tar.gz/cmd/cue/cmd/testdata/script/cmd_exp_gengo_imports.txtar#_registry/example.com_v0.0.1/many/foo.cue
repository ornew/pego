package foo

#Foo: int
