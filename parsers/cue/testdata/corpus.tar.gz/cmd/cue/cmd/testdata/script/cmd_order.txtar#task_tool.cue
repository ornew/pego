package ci

import (
    "tool/cli"
)

command: gen: cli.Print & {
	text: {
		#early: *"X" | string
		#early
	} & {// NEEDED
		#early: *"X" | string
		string
	}
}
