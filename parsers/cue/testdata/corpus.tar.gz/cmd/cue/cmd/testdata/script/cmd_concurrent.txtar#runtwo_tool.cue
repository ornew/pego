package hello

import (
	"tool/cli"
	"tool/exec"
)

command: runtwo: {
    foo: exec.Run & {
        cmd:    ["testcmd", "concurrent", "foo", "bar"]
        stdout: string
    }
    bar: exec.Run & {
        cmd:    ["testcmd", "concurrent", "bar", "foo"]
		stdout: string
    }
	results: cli.Print & {
		text: "foo: \(foo.stdout)\nbar: \(bar.stdout)"
	}
}
