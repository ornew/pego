package foo

#SomeBaseType: {
	"a" | "b"
	#AUTO: "z"
}

V1: ("x" | "y") | *"z"
V2: ("x" | "y") | *#SomeBaseType.#AUTO

