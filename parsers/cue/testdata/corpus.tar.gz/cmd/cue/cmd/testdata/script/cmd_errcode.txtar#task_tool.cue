package home

import "tool/exec"

command: errcode: {
	task: bad: exec.Run & {
		cmd: ["testcmd", "exitcode", "5"]
	}
}
