package mkdirtmp

import (
	"tool/file"
)

command: mkdirtmp: {
	tmp: file.MkdirTemp & {
		path: string
	}

	rm: file.RemoveAll & {
		path:    tmp.path
		success: true
	}
}
