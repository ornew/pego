module: "test.example/m2"
language: {
    version: "v0.12.0"
}
source: kind: "self"
