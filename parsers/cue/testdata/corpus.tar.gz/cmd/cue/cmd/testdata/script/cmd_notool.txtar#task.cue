package home

import "tool/cli"

message: "Hello world!"

command: notool: cli.Print & {
	task: display: {
		text: 42
	}
}
