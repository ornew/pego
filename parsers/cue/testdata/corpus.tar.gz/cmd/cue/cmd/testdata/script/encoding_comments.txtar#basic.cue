// comment at the start of a file.

// Package p is an example package.
package p

// top-level comment before a simple field.
foo: "bar"
// top-level comment after a simple field.

// top-level comment before a struct
struct: {
	// comment at the start of a struct.

	// comment in a struct field
	field1: "message1"

	// comment between struct fields.

	field2: "message2"

	// comment at the end of a struct.
}

// top-level comment before a list.
list: [
	// comment at the start of a list.

	1,
	// comment in a list element.
	2,

	// comment between list elements.

	3,

	// comment at the end of a list.
]

// comment at the end of a file.
