package x

import "list"

x: [1, 2, 3]
// This is a fatal error, as the passed struct will never be
// able to contain `less` by making the configuration more concrete.
sortedx: list.Sort(x, {})

