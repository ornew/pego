@extern(embed)

package foo

a: _ @embed(glob="*.json")
