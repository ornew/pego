package foo

#Foo: int

