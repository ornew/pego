package pkg

v: { x: 3, y: x }

