package cuetest

import "foo.test/bar/root"

// Note that it would be nice to sanity check that all tests result in an error,
// for example by using matchN or list.MatchN somehow.
fail: [_]: [_]: root.#root
fail: both: notString: "not_a_struct"

