Foo: {
	foo?: Foo
	bar:  string
	baz:  bar + "2"
}

foo: Foo & {
	foo: {
		bar: "barNested"
	}
	bar: "barParent"
}
