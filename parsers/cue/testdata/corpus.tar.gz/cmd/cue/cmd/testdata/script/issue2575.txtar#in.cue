#Def: {
	_in: string
	result: string | *null
	result: string | *_in
}

out: #Def & {_in: "must-print"}
