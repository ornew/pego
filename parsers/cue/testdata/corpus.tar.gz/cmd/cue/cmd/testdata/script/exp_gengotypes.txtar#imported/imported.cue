package imported

import "foo.test/bar/imported/indirect"

// These should be ignored as they are not exported definitions.
regularNeverGenerate: string
_hiddenNeverGenerate: string

#instanceStruct: {
	instanceField: int

	indirectField: indirect.#Indirect
}
