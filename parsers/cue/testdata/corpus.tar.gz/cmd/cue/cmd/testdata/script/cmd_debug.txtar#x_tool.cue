package x

import (
	"tool/cli"
)

command: bar: {
	a: cli.Print & {
		text: "a"
	}
	"\"b#": cli.Print & {
		text:   "b"
		$after: a
	}

}
