dir: string @tag(dir,var=userz)

