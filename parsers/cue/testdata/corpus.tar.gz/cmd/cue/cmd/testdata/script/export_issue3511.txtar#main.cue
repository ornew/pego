package p

import "module.test/foo/imported@v0"

items: [imported.List]
