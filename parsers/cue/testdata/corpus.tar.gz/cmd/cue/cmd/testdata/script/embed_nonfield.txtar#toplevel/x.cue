@extern(embed)

package toplevel
@embed(file="x.json")
