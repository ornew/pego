package root

import (
	"list"
	"time"
)

#types: {
	// The field names below are capitalized to avoid name clashes.

	Top?: _
	// Do we care about bottom?

	Null?:   null
	Bool?:   bool
	Int?:    int
	Float?:  float
	String?: string
	Bytes?:  bytes

	Number?: number
	Uint?:   uint
	Int8?:   int8
	Rune?:   rune

	IntList?:        [...int]
	IntListClosed2?: [int, int]
	IntMap?:         [string]: int

	Time?:     time.Time
	Duration?: time.Duration

	StringOrInt?:        string | int
	StringOrIntDefault?: string | *int
	NullOrStruct?:       null | {foo?: int}
	NullOrString?:       null | string
	NumericBounds?:      >0 & <100
	NonEmptyString?:     string & != ""
	UniqueStrings?:      list.UniqueItems & [... string]
	LinkedList?:         #linkedList
	GraphNode?:          #graphNode
}

#linkedList: {
	item?: _
	next?: #linkedList
}

#graphNode: {
	edges?: [...#graphNode]
}
