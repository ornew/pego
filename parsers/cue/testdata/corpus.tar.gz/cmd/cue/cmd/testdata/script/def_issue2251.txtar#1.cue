import "example.com/repro/foo"

foo.#Foo

a: "A"

