package bar

b: 1

