package x
import (
	"tool/cli"
	"mod.test/hello"
)

// This should pull in the hello task.
hello

command: hello1: task: hello: cli.Print & {
	text: "hello, world"
}
