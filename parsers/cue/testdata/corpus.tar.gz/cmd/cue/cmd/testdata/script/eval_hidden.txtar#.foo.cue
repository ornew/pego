package foo

a: 42
