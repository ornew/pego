package pkg1

#Foo: int
#Bar: string
