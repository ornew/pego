package home

import (
	"tool/cli"
	"tool/exec"
)

command: ref: {
	t1: exec.Run & {
			ref: t1.stdout
			cmd: ["echo", "hello"]
			stdout: string
	}
	t2: cli.Print & {
		text: t1.stdout
	}
}

