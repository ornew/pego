package x

import   "mod.test/x/emptypkg"

x: 5
