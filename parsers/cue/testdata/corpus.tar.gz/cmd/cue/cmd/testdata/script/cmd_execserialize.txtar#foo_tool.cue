package foo

import (
	"encoding/json"
	"tool/cli"
	"tool/exec"
)

command: printTask: {
	task: exec.Run & {
		cmd: ["true"]
		stdout: string
	}
	print: cli.Print & {
		text: json.Marshal(task)
	}
}
