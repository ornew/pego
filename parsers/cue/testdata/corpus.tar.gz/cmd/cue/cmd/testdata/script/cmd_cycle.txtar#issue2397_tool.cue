package test

import (
        "encoding/yaml"
        "tool/cli"
)

command: kube: {
        task: print: cli.Print & {
                text: yaml.Marshal(obj)
        }
}


