package x

import (
 "tool/cli"

 "mod.test/test/sub"
)

command: foo: cli.Print & {
 text: "test \(sub.User)"
}
