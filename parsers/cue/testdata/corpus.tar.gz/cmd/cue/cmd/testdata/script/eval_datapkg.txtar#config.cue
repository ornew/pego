package config

import (
	"mod.test/config/components:widget"
)

w: widget.#Widget

