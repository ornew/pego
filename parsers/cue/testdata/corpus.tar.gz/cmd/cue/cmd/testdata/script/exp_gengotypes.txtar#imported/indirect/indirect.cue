package indirect

#Indirect: int
