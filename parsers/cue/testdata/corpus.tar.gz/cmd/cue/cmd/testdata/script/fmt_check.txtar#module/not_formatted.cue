package module
foo:    "bar"
