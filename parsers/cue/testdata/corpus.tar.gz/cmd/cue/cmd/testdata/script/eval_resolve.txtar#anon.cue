// This is an explicitly declared anonymous package.
package _

nodes: [{
    name: "foo"
    childs: ["bar", "baz"]
}, {
    name:   "bar"
    parent: "foo"
}, {
    name:   "baz"
    parent: "foo"
}]

