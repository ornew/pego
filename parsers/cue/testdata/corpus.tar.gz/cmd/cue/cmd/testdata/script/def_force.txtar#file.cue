package hello

#who:    "World"
message: "Hello \(#who)!"
