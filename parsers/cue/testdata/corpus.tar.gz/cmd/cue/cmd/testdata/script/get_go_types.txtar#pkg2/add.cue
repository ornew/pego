package pkgtwo

Barzer: {
	S: =~"cat$"
}
