// 2.cue: file comment 1

// 2.cue: file comment 2

// 2.cue: doc comment
package t

// 2.cue: d
d:   1
di:  1
dii: 1
