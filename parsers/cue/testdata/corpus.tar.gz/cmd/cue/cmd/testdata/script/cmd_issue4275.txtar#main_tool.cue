package p

import (
	"encoding/json"
	"tool/cli"
)

command: main: cli.Print & {
	text: json.Marshal(data)
}
