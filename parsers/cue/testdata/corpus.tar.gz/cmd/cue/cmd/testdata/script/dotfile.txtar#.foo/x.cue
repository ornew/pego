package foo

x: 1

