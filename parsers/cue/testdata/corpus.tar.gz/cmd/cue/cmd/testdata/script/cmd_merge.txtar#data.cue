package p

#Schema1: f1: #Schema2
#Schema2: f2?: #Schema3
#Schema3: f3?: #Schema4
#Schema4: f4?: {...}

a1: #Schema1 & {
    f1: f2: f3: f4: values
}
values: v1: v2: [{v3: ["v4"]}]
