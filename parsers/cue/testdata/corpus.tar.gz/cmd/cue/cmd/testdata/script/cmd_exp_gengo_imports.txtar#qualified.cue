package p

// A qualified import from a directory holding multiple packages.
import "mod.test/many:foo"

#Qualified: foo.#Foo
