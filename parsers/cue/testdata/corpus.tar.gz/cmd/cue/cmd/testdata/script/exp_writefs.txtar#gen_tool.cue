package p

import (
	"encoding/json"
	"tool/exec"
)

command: gen: exec.Run & {
	cmd: ["cue", "exp", "writefs"]
	stdin: json.Marshal({
		tool: "cue cmd gen"
		remove: ["out/*.json"]
		create: {
			"out/foo.yaml":         {contents: foo: "as yaml"}
			"out/foo.json":         {contents: foo: "as json"}
			"out/foo.toml":         {contents: foo: "as toml"}
			"out/foo.txt":          {contents: "plain text"}
			"out/foo-noext":        {contents: "plain text"}
			"out/foo.custom":       {encoding: "yaml", contents: foo: "as yaml"}
			"out/link.yaml":        {type: "symlink", contents: "foo.yaml"}
			"out/sub/dir/foo.yaml": {type: "file", contents: foo: "in nested dir"}
		}
	})
}

