#foo: "bar"
out: #foo
