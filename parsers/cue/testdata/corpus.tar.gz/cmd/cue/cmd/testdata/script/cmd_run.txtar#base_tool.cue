package home

import (
	"tool/cli"
	"tool/exec"
)

// deliberately put in another file to test resolving top-level identifiers
// in different files.
#RunBase: {
	task: echo: exec.Run & {
		stdout: string
	}

	task: display: cli.Print & {
		text: task.echo.stdout
	}
}
