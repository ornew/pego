module: "example.com/e@v0"
language: version: "v0.8.0"

