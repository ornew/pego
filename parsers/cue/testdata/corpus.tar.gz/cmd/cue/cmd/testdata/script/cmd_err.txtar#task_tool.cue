package home

import "tool/file"

command: ref: {
	task: display: file.Create & {
        filename: filename
	}
}
