import (
	"list"
)

#Team: [string]: [...("EM" | "IC" | "TL")]

team: #Team

checks: {
	enoughMembers: {
		ok: len(team) >= 1
	}

	hasManager: {
		ok: len([for m in team if list.Contains(m, "EM") {m}]) >= 1
	}
}
