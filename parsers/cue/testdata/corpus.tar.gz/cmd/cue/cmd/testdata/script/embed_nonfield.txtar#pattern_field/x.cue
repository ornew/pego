@extern(embed)
package dynamic_field

[_]: _ @embed(file=x.json)
x: _
