package home

import (
    "tool/os"
    "strconv"
    "mod.test/test/sub"
)

command: tool: {
    bad: os.DoesntExist & {
        input: "a"
    }
}

command: builtin: {
    bad: strconv.DoesntExist & {
        a: "b"
    }
}

command: package: {
    bad: sub.DoesntExist
}
