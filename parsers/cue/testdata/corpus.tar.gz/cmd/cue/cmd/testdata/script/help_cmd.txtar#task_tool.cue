package home

import "tool/cli"

// say hello to someone
//
//   Usage: hello
//
// Hello can be used to say hello to the world.
command: hello: {
    task: say: {
        cli.Print
        text: "Hello world!"
    }
}

// echo something back
command: echo: {
    task: echo: {
        cli.Print
        text: "ECHO Echo echo..."
    }
}

