module: "mod.example"
language: version: "v0.9.0"
