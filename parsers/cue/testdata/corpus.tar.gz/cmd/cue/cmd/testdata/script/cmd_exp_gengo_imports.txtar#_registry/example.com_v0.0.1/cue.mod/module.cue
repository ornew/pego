module: "example.com@v0"
language: version: "v0.8.0"

