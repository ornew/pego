package p

import same "mod.test/bar"

#Conflict: bar: same.#Bar
