#Suffix:      string
#MaybeSuffix: ""

if len(#Suffix) > 0 {
	#MaybeSuffix: "-\(#Suffix)"
}

ConfigMap: "\(#MaybeSuffix)"
