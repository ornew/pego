package two

out: 3 * ["baz"]
