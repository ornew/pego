hostname: string @tag(hostname,var=hostname)

