package p

import "externalmod.test/imports/root"

root.Type
