package foo

import (
	"tool/cli"
	"tool/file"
)

command: test: {
	hiddenRefs: {
		letRef: letName
		hid:    _hid
		def:    #def
		hidDef: _#hidDef
	}
	afterHidden: cli.Print & {
		$after: [for t in hiddenRefs {t}]
		text: """
			\(hiddenRefs.letRef.contents)
			\(hiddenRefs.hid.contents)
			\(hiddenRefs.def.contents)
			\(hiddenRefs.hidDef.contents)
			"""
	}
}

let letName = file.Read & {filename: "read.txt"}
_hid: file.Read & {filename: "read.txt"}
#def: file.Read & {filename: "read.txt"}
_#hidDef: file.Read & {filename: "read.txt"}
