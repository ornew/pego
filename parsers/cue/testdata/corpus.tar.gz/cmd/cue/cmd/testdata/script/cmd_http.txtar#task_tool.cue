package home

import (
	"tool/cli"
	h "tool/http"
	"tool/os"
)

command: http: {
	env: os.Getenv & {
        GOPROXY: string
	}
	task: http: h.Get & {
		url: env.GOPROXY + "/externalmod.test/imports/@v/v1.0.0.info"

		response: body: string // TODO: allow this to be a struct, parsing the body.
	}
	task: print: cli.Print & {
		text: task.http.response.body
	}
}
