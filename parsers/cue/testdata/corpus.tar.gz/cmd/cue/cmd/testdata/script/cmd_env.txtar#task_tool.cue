package home

import (
    "tool/os"
    "tool/cli"
)

command: env: {
	env: os.Getenv & {
        TESTNUM: *<10 | string
        MYTEXT:  string
	}
	print: cli.Print & {
		text: "Hello \(env.MYTEXT)!"
	}
}

// Should fail when the MYTEXT env var is set.
command: issue3908: {
	env: os.Environ
	_mytext: env.MYTEXT | "fallback"
	print: cli.Print & {
		text: _mytext
	}
}
