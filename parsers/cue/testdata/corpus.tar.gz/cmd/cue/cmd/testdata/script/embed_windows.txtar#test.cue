@extern(embed)

package foo

// Unix OSes can have a file containing a star character, and we can match it.
// Windows can still use these file paths and glob patterns, but they can't match
// a file containing a star character, as such filenames are not allowed on Windows.

globStar:       _ @embed(glob="star/*.json")
globEscapeStar: _ @embed(glob="star/\\**", type=json)
