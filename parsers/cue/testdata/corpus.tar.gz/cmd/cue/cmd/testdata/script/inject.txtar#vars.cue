import "path"

_os: string @tag(os,var=os)
_dir: string @tag(dir,var=cwd)

base: path.Base(_dir, _os)

