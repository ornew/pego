package hello

import "list"

out: list.Repeat(["x"], 2000)
