package test

#obj: {
        requests?: {
                memory?: int & <=limits.memory
        }
        limits?: {
                memory?: int & <=100Gi
        }
}

// Stack overflow, but only in `cue cmd`.
obj: #obj & {
        requests: memory: 1Gi
		// The problem in the original bug report was with this reference.
        limits: memory:   requests.memory
}

