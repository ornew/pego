package root

import (
	"foo.test/bar/imported/multipkg:multipkg_one"
	"foo.test/bar/imported/multipkg:multipkg_two"
	"foo.test/bar/imported/subinst:imported"
	"foo.test/bar/imported/unused"
)

#rootImports: {
	inst?: imported.#instanceStruct

	lowerRegular?: imported.lowerRegular
	UpperRegular?: imported.UpperRegular
	lowerDef?:     imported.#lowerDef
	UpperDef?:     imported.#UpperDef

	multiOne?: multipkg_one.#One
	multiTwo?: multipkg_two.#Two

	optionalRemoteMapAttrNillable?:     imported.#remoteMap @go(,optional=nillable)
	optionalRemoteNestedAttrNillable?:  imported.#remoteNested @go(,optional=nillable)
}

// Embedding an imported definition whose fields reference sibling definitions
// in its own package used to panic; see https://cuelang.org/issue/4436.
#embedImported: {
	imported.#refOuter
	extra?: string
}

_unusedImport: unused.#UnusedNeverGenerate
