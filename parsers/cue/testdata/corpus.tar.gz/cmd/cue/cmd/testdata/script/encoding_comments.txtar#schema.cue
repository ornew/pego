package p

// Schema declares a schema.
#Schema: {
	// name is the schema name.
	name?: string
}
