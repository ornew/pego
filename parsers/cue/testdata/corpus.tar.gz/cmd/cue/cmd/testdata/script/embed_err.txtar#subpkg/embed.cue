@extern(embed)

package subpkg

// This file is in a subdirectory but ../test.json is still inside the module.
// Parent directory references should still be rejected.
parentFile: _ @embed(file="../test.json")
parentGlob: _ @embed(glob="../*.json")
