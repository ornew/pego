package Vector

#D2: {
    X: float
    Y: float
}

#D3: {
    X: float
    Y: float
    Z: float
}

