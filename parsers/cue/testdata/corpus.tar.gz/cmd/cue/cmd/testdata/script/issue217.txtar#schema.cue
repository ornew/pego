package tst

x: {
	a: #A
	b: #A
}

#A: string | [#A]

