@extern(embed)

package foo

import (
    "strings"
    "tool/cli"
)

embedded_toolfile: _ @embed(file="input.yaml", type=text)

command: test: {
    regularFile: cli.Print & {
        text: "from foo.cue: \(strings.TrimSpace(c))"
    }
    toolFile: cli.Print & {
        $after: regularFile // for consistent output
        text: "from foo_tool.cue: \(strings.TrimSpace(embedded_toolfile))"
    }
}

