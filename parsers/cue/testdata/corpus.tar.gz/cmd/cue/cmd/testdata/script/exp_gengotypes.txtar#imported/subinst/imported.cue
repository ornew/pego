package imported

#instanceStruct: _

lowerRegular: int
UpperRegular: int
#lowerDef: int
#UpperDef: int

#remoteMap: [string]: int
#remoteNested: f?: [...string]

#refOuter: {
	name:   string
	inner?: #refInner
}
#refInner: x: int
