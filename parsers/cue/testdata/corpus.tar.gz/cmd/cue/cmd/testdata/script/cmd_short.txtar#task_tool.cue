package home

import "tool/cli"

command: hello: cli.Print & {
	text: "Hello world!"
}
