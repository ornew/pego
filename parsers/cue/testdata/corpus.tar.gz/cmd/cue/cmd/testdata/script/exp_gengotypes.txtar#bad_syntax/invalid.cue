package bad_syntax

// This CUE package is not referenced nor used anywhere, so it should not be loaded.
{ bad syntax
