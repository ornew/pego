package cuetest

import "foo.test/bar/root"

pass: [_]: root.#root

