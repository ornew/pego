package p

import (
    "tool/exec"
    "encoding/json"
)

command: {
    one: exec.Run & {
        stdin: "{\"msg\": \"hello\"}"
        cmd: ["cat"]
        stdout: string
    }
    two: exec.Run & {
        let data = json.Unmarshal(one.stdout)
        cmd: ["cat"] // "true" is printed for each json value read
        stdin: json.Marshal(data) + "\n"
    }
}
