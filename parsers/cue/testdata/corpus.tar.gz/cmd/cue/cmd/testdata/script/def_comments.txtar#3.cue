// 3.cue: pkg doc comment
package t

// 3.cue: pkg comment 1

// 3.cue: d comment
d:   1
di:  1
dii: 1
