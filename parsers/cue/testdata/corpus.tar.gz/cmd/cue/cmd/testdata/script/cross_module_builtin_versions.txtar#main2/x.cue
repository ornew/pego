package x

import "test.example/m2"

x: int | string | m2.err("some custom error")
x: false

