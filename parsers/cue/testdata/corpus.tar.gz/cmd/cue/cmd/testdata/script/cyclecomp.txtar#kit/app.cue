package kit

#S: {}

#A: X={
    t: #S
    if X.t != null {
        out: 1
    }
}
