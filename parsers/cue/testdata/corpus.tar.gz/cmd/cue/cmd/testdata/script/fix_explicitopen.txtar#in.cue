package foo

#A: a: int
#B: b: int

X: {
	#A // foo

	// bar
	#B
	b: string
}
