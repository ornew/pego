checks: [string]: ok: true

