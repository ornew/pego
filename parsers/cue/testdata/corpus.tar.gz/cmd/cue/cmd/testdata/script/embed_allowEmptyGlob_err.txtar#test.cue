@extern(embed)

package foo

// This should fail because no files match and allowEmptyGlob is not present.
noMatches: _ @embed(glob="missing/*.json")

// This should also fail because allowEmptyGlob is not present.
alsoNoMatches: _ @embed(glob="nonexistent/*.yaml")

// This should fail because allowEmptyGlob must be specified alongside
// a glob pattern.
noGlobField: _ @embed(file="foo",allowEmptyGlob)

