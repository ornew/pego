package somefile

location: "in cue.mod"
