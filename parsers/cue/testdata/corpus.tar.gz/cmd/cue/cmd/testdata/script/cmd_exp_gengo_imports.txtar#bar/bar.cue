package bar

#Bar: string
