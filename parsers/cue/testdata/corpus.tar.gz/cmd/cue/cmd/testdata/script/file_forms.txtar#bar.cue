a: 4
b: {
    c: a
}

