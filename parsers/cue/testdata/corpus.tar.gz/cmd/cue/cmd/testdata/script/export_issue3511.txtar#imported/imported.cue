package imported

Namespace: "default"

List: [...{namespace: Namespace}]

List: [{name: "kube-api-server"}]
