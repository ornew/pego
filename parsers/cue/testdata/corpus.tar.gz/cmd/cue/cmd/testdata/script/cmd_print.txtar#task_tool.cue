package home

import (
	"tool/exec"
	"tool/cli"
	"strings"
)

command: print: {
	runs: t1: exec.Run & {
		cmd: ["testcmd", "sleep_and_print", "100ms", "t1"]
		stdout: string
	}
	runs: t2: exec.Run & {
		cmd: ["testcmd", "sleep_and_print", "100ms", "t2"]
		stdout: string
	}
	print: cli.Print & {
		text: (#f & {arg: runs.t1.stdout + runs.t2.stdout}).result
	}
}

#f: {
    arg: string
    result: strings.Join(strings.Split(arg, ""), ".")
}
