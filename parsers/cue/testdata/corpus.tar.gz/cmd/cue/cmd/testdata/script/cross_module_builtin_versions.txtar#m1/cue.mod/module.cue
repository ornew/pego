module: "test.example/m1"
language: {
    version: "v0.14.0"
}
source: kind: "self"
