package otherpkg

#Foo: int
