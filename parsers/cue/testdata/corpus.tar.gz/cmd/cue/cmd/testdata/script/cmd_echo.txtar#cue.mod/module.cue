module: "mod.test/foo"
language: version: "v0.9.0"

