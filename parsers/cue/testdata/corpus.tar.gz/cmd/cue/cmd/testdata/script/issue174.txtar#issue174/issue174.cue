import 'foo'

a: 1
