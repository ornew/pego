a: int @protobuf(1,int64) // to string
b: int @protobuf(2,int32) // also allow string
c: int // also allow
d: float
s: string
t: bytes

