package hello

$type:   "demo"
message: "Hello \(#who)!" // who declared in data.cue
