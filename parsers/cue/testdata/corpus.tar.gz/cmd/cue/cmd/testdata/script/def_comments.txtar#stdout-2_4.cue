// 2.cue: doc comment
//
// 4.cue: doc comment

// 2.cue: file comment 1

// 2.cue: file comment 2

// 4.cue: file comment 1

// 4.cue: file comment 2

// 2.cue: d

// 4.cue: d
d:   1
di:  1
dii: 1
