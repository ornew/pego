// foo
package foo

#A: {
    // a is an integer
    a: int
    b: { c: int } // TODO: should we _not_ simplify?
}

