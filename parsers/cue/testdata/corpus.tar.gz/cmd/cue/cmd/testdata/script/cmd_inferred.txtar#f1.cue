package kube

pkg: {
	#Def: {
		a: int
		b: #Role
	}
	#Role: {
		kind: string
		name: string
	}

}

test: pkg.#Def
test: {
    a: 1
	b: {
		kind: "foo"
		name: "bar"
	}
}

// A kind at the top-level should not be allowed.

kind: "foo"
$id: "bar"

