package tags


var: env: "prod" | "staging" @tag(env,short=prod|staging)
var: name: string @tag(name)

// This is prohibited as for now.
// foo: [string]: string @tag(all)
// foo: bar: string
