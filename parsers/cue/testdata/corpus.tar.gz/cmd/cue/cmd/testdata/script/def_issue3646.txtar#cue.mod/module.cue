module: "example.com/def"
language: {
	version: "v0.9.2"
}
