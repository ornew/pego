root: {
	message: $$: "Hello World!"
	nested: {
		a1: $$: "one level"
		a2: b: $$: "two levels"
	}
}
