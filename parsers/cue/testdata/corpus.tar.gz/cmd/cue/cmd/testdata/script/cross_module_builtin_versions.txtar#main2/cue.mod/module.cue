module: "other.example/x"
language: {
    version: "v0.12.0"
}
deps: {
    "test.example/m2@v0": {
        v:       "v0.0.0"
        default: true
    }
}
