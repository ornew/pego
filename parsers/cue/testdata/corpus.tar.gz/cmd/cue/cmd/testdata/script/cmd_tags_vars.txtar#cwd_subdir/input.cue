package p

import (
	"path"
	"time"
)

// The current time is constantly changing,
// so simply check that it's valid and between 2020 and 3000.
_now: string @tag(now,var=now)
_parts: time.Split(_now)
nowValidYear: _parts.year > 2020 && _parts.year < 3000

// The current directory will include a temporary directory,
// so extract the basename only, which we can control here.
_cwd: string @tag(cwd,var=cwd)
cwdBase: path.Base(_cwd, os)

// os and arch are just Go's GOOS and GOARCH, validated via cmpenv.
os: string @tag(os,var=os)
arch: string @tag(arch,var=arch)

