package x

#Schema: {
    optional: string
}
d: #Schema
d: {
    optional: "some"
}
