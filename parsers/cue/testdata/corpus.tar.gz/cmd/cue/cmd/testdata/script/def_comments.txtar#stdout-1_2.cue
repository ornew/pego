// 1.cue: file comment

// 2.cue: file comment 1

// 2.cue: file comment 2

// 1.cue: pkg doc comment
//
// 2.cue: doc comment
package t // 1.cue: pkg comment 1

// 1.cue: pkg comment 2

// 1.cue: d comment

// 2.cue: d
d:   1
di:  1
dii: 1
