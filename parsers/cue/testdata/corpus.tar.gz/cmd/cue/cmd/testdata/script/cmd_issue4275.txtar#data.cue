package p

data: [_]: d2: foo: 0
if true {
	data: d1: d2: bar: 1
}
