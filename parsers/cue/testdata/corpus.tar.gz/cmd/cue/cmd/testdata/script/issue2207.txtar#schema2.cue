x: {
	a: int
	if a > 100 {
		b: true
	}
}
