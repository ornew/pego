package foo

x: "yyy"
