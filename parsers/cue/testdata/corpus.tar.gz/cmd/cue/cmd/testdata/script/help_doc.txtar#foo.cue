package bar

name: "foo"
_D: int

