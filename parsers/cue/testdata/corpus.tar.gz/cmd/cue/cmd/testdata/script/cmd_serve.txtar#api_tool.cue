package vm

import (
	"encoding/json"
	"encoding/openapi"
)

//#Machine describes a virtual machine.
#Machine: {
	os!:     "Windows" | "Linux" | "MacOS"
	arch!:   "x86" | "arm64"
	mem?:    int
	disk?:   int
	access?: {
		public?: bool
	}
}

// MachineByRole defines different machine configurations that are allowed
// based on user role.
MachineByRole: {
	admin: #Machine

	// Interns are only afforded smaller machines.
	intern: #Machine&{
		mem?:  <=4Gi
		disk?: <=100G
	}

	research: #Machine&{
		// The research team cannot launch public-facing machines.
		access?: public?: false
		os?:     "Linux" | "Windows"
	}
	default: null
}

Membership: alice: "admin"
Membership: bob: "research"
Membership: taylor: "intern"

// This API gets the allowed VM configurations for a given user defined as
// OpenAPI. The user is specified as a query parameter.
// If no user is given, a generic OpenAPI schema for Machine is returned.
command: serve: "/schema/api/vm": {
	routing: method: "GET"

	// Define default for user query parameter.
	request: form: r: *[""] | [...string]

	let role = request.form.r[0]
	let X = [// select first
		if MachineByRole[role] != _|_ {
			config: {
				version: "3.0.0"
				info: title: "Machine for \(role)"
			}

			// TODO: note: if this is a disjunction it won't get converted to
			// OpenAPI properly.

			machine: MachineByRole[role]
		},
		{
			config: {
				version: "3.0.0"
				info: title: "Machine"
			}
			machine: #Machine
		}, // default
	][0]

	response: body: json.Indent(
		openapi.MarshalSchema(X.config, {#Machine: X.machine}), "", "  ")
}

// This API simulates creating a new VM for a given user, specified as a query
// parameter. The machine is requested in the JSON body. It is than checked
// that the user can actually use the machine.
command: serve: "/api/vm": {
	routing: method: "POST"

	// Further constrain user permissions.
	request: form: u!: [string]

	let user = request.form.u[0]
	let role = Membership[user]

	// Validate the request to create a new VM against the VM schema.
	X: #Machine
	X: json.Unmarshal(request.body)
	X: MachineByRole[role]

	response: {
		header: "Content-Type": "application/json"

		result: "OK"
		body:   json.Marshal(result)
	}
}

// This API demonstrates returning a custom 201 Created status code.
command: serve: "/api/vm/create": {
	routing: method: "POST"

	request: form: u!: [string, ...string]

	response: {
		header: "Content-Type": "application/json"
		statusCode: 201
		body: json.Marshal({
			status: "created"
			user:   request.form.u[0]
		})
	}
}

// This API demonstrates returning a custom 400 Bad Request status code.
command: serve: "/api/error": {
	routing: method: "POST"

	response: {
		header: "Content-Type": "application/json"
		statusCode: 400
		body: json.Marshal({
			error: "missing required parameter: u"
		})
	}
}

