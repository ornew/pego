package v1

import (
	"time"
	"googleapis.com/acme/test"
	"googleapis.com/acme/test/test:test_test"
)

// Attributes defines attributes.
#Attributes: {
	#Type:
		#TYPE_A |
		#TYPE_B

	#TYPE_A: 1
	#TYPE_B: 2

	#Type_value: {
		TYPE_A: 1
		TYPE_B: 2
	}

	// A map of attribute name to its value.
	attributes?: {
		[string]: #AttributeValue
	} @protobuf(1,map[string]AttributeValue)

	// Specifies one attribute value with different type.
	#AttributeValue: {
		// The attribute value.
		{} | {
			stringValue: string @protobuf(2,string,name=string_value)
		} | {
			int64Value: int64 @protobuf(3,int64,name=int64_value)
		} | {
			doubleValue: float64 @protobuf(4,double,name=double_value)
		} | {
			boolValue: bool @protobuf(5,bool,name=bool_value)
		} | {
			bytesValue: bytes @protobuf(6,bytes,name=bytes_value)
		} | {
			timestampValue: time.Time @protobuf(7,google.protobuf.Timestamp,name=timestamp_value)
		} | {
			// Used for values of type STRING_MAP
			stringMapValue: #StringMap @protobuf(9,StringMap,name=string_map_value)
		} | {
			testValue: test.#Test @protobuf(10,acme.test.Test,name=test_value)
		} | {
			testValue: test_test.#AnotherTest @protobuf(11,acme.test.test.AnotherTest,name=test_value)
		}
	}

	// Defines a string map.
	#StringMap: {
		// Holds a set of name/value pairs.
		entries?: {
			[string]: string
		} @protobuf(1,map[string]string)
	}
}
