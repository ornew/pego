package test

#Test: {
	test?: int32 @protobuf(1,int32)
}
