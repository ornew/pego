package pkg2

#Baz: bool
