package nested

A: {
    a: int @protobuf(1,int64) // to string
    b: bytes
}

B: {
    a: int @protobuf(1,int64) // to string
    s: string
}

