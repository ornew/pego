package bar

location: "in cue.mod/pkg/foo.com/bar"
