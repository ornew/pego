#Def: int
x:    #Def & 5

