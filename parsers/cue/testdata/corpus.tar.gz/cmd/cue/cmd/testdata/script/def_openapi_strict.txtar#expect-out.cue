info: {
	title:   *"My OpenAPI" | string
	version: *"v1alpha1" | string
}
#Bar: {
	...
}
