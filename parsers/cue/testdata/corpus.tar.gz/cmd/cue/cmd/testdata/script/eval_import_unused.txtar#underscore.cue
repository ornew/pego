package _

import "list"

out: 123
