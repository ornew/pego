package foo

c: 42
