package home

import "tool/cli"

command: baddisplay: {
	display: cli.Print & {
		text: 42
	}
}
