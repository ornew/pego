package tangle_sublime

import (
	"encoding/yaml"
	"tool/cli"
)

command: tangle_sublime: {
	debugSourceFile: cli.Print & {text: yaml.Marshal(buildSource)}
}

v: w: 0

let X = {c: d: v}

a: b: X.c

command: ts: cli.Print & {text: "foo", x: a}

