// 1.cue: file comment

// 1.cue: pkg doc comment
package t  // 1.cue: pkg comment 1

// 1.cue: pkg comment 2

// 1.cue: d comment
d:   1

// 1.cue: d comment 1

di:  1
dii: 1

