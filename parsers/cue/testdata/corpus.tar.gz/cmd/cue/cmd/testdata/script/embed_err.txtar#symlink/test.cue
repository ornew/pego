@extern(embed)

package symlink

file: _ @embed(file=symlink.json)

glob: _ @embed(glob="*.json")

fileSymlinkDir: _ @embed(file=symlink-dir/test.json)

globSymlinkDir: _ @embed(glob="symlink-dir/*.json")
