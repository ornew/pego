{
    environment: "prod" | "staging" @tag(env,short=prod|staging)

    // Don't replace in optional
    opt?: string @tag(env)
    bulk: [string]: foo: string @tag(env)
    bulk: x: {}

    // Don't replace in lists.
    a: [
        { no_replace: string @tag(env) }
    ]

    // Don't allow in comprehensions
    src: [1, 2]
    for _ in src {
        b: string @tag(prod)
    }
}

