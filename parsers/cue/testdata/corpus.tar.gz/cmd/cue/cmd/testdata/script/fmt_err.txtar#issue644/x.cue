package x

import   "mod.test/x/nosuchpkg"

x: 5
y: unresolved
