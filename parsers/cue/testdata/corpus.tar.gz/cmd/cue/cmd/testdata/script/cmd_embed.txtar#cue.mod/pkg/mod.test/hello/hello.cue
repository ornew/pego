package hello

import "tool/cli"

command: hello: task: hello: cli.Print & {
	text: "hello, world"
}
