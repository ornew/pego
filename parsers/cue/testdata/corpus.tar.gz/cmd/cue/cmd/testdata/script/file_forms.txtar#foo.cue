a: 4
b: {
    c: 1
}
// Duplicates are still allowed.
b: {
    d: 2
}

