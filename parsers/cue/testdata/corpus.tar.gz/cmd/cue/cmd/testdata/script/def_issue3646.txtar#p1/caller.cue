package p1

import (
	"example.com/def/p2"
)

r: "us-east-1"
shortRegionName: p2.regionMap[r]

