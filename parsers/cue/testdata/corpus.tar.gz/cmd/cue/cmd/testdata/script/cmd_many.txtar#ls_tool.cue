package x

import (
	"tool/cli"
	"strings"
)

command: ls: cli.Print & {
	text: "ls: " + strings.Join(itemsList, " ") + "\n"
}
