import "struct"

#c: matchN(1, [{
	a!: _
	c?: _
}, {
	b!: _
	c?: _
}]) & {
	c!: _
}

d: struct.MinFields(3) & {
	x!: 4
	...
}
issue3633: {
	// With nested matchNs as below, the schema will become an incomplete error
	// as a value of the root vertex. Make sure this edge case is properly
	// handled.
	data: {} & #s
	#s: matchN(1, [matchN(1, [{a!: _}])])
}
