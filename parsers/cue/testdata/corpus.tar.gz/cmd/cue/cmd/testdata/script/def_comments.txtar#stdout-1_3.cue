// 1.cue: file comment

// 1.cue: pkg doc comment
//
// 3.cue: pkg doc comment
package t // 1.cue: pkg comment 1

// 1.cue: pkg comment 2

// 3.cue: pkg comment 1

// 1.cue: d comment

// 3.cue: d comment
d:   1
di:  1
dii: 1
