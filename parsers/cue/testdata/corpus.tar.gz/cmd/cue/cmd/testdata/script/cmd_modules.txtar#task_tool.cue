package home

import (
	"tool/cli"
	textPkg "foo.example/text"
)

command: print: {
	print: cli.Print & {
		text: "hello, \(textPkg.value)"
	}
}
