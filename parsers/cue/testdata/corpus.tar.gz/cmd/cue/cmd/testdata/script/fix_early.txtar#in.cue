package foo

#A: a: int

X: {
	#A
}
