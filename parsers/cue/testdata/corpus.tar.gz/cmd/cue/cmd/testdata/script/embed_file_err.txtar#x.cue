@extern(embed)

package x

e: _ @embed(glob="*.json",type=jsonschema)

