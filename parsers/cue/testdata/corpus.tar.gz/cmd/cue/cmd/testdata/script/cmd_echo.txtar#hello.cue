package hello

message: "Hello \(_who)!" // who declared in data.cue
