@extern(embed)
package dynamic_field

a: "foo"
(a): _ @embed(file=x.json)
