@extern(embed)

package foo

import "example.com/e"

a: _ @embed(file="test.json")

b: _ @embed(file="x/test.json")

c: e.a

