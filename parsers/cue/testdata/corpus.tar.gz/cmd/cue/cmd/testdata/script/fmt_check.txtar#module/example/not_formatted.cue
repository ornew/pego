package module
foo:      "bar"
