foo: int
bar: 3
