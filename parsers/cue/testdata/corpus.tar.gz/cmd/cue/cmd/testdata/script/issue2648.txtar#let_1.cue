package p

crossfile_let: "referenced from sibling file"
let L = true
if L {
    let1_used: true
}
