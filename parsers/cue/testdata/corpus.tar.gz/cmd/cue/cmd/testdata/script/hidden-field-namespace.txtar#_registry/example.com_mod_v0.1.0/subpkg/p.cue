package subpkg

#foo: {
	_x?: int
	result: *(_x + 10) | -1
}

#withx: {
	in!: int
	out: {
		_x: in
	}
}
