package foo

import (
	"tool/cli"
    "tool/file"
)


command: prompter: {
	ask: cli.Ask & {
		prompt:   "What is your name?"
		response: string
	}

	// inadvertently defined at top level, masking other tasks.
	file.Append & {
		contents: ask.response
	}
}
