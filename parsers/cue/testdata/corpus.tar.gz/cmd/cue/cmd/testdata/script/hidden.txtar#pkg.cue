package pkg

_top: 1

a: _h0: int

#foo: {
    _h1: string
}

{
    _h2: string
}

