package x

import "test.example/m1"

x: int | string | m1.err("some custom error")
x: true

