package otherpkg

#Foo: int

