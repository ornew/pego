package foo

#A: a: int